<?php $__env->startSection('title', 'Account'); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="background-image: url('<?php echo e(asset('images/bg2.jpg')); ?>');" class="breadcrumb-section jarallax pixels-bg" data-jarallax data-speed="0.6">
    <div class="container text-center">
        <h1>Account</h1>
        <ul>
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li><a href="javascript:void(0);">Page</a></li>
            <li><a href="javascript:void(0);">Account</a></li>
        </ul>
    </div>
</div>

<div class="section-block">
    <div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-12 col-12">
                <div class="row">
                <div class="col-md-4 col-sm-4 col-12">
                    <div class="section-heading">
                        <h6 class="semi-bold">Account Details</h6>
                        <ul class="grey-list mt-15">
                            <li><i class="fa fa-user"></i> <?php echo e($user->fname); ?> <?php echo e($user->lname); ?></li>
                            <li><i class="fa fa-map-marker-alt"></i> <?php echo e($user->address); ?></li>
                            <li><i class="fa fa-phone"></i><?php echo e($user->tel); ?></li>
                            <li><i class="fa fa-envelope-open"></i> <?php echo e($user->email); ?></li>
                        </ul>
                        
                    </div>
                </div>
                <div class="col-md-8 col-sm-12 col-12">
                    <h4>Recent Orders</h4>
                    <p>My recent orders</p>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Date Created</th>
                            <th>Amount (<?php echo e($comm->currency); ?>)</th>
                            <th>Payment Status</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $od): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($od->order_code); ?></td>
                            <td><?php echo e(date("d F, Y",strtotime($od->created_at))); ?></td>
                            <td><?php echo e(number_format($od->total_amount,2)); ?></td>
                            <?php if($od->payment_status == SUCCESSFUL): ?>
                            <td><span style="color: green">successful</span></td>
                            <?php elseif($od->payment_status == UNSUCESSFUL): ?>
                            <td><span style="color: red">unsuccessful</span></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </tbody>
                    </table>
                    <div class="text-right">
                        <a href="<?php echo e(url('user/orders')); ?>" class="button-md button-primary">View All My Transactions</a>
                    </div>
                    </div>
                </div>
                </div>
           <?php echo $__env->make('includes.user-side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'layouts.user' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jesus-care\resources\views/user/account.blade.php ENDPATH**/ ?>
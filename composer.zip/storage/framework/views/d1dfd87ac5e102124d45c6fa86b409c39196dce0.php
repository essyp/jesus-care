<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="background-image: url('<?php echo e(asset('images/bg2.jpg')); ?>');" class="breadcrumb-section jarallax pixels-bg" data-jarallax data-speed="0.6">
    <div class="container text-center">
        <h1>Orders</h1>
        <ul>
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li><a href="javascript:void(0);">Page</a></li>
            <li><a href="javascript:void(0);">Orders</a></li>
        </ul>
    </div>
</div>

<div class="section-block">
    <div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-12 col-12">
                <h4>My Orders</h4>
                <p>All my orders from the ministry shop</p>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Date Created</th>
                        <th>Amount (<?php echo e($comm->currency); ?>)</th>
                        <th>Payment Type</th>
                        <th>Status</th>
                        <th>Payment Status</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $od): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($od->order_code); ?></td>
                        <td><?php echo e(date("d F, Y",strtotime($od->created_at))); ?></td>
                        <td><?php echo e(number_format($od->total_amount,2)); ?></td>
                        <td><?php echo e($od->gateway->name); ?></td>
                        <?php if($od->status == PROCESSING): ?>
                        <td><span style="color: orange">processing</span></td>
                        <?php elseif($od->status == ACTIVE): ?>
                        <td><span style="color: green">active</span></td>
                        <?php elseif($od->status == CANCELED): ?>
                        <td><span style="color: red">canceled</span></td>
                        <?php else: ?>
                        <td></td>
                        <?php endif; ?>

                        <?php if($od->payment_status == SUCCESSFUL): ?>
                        <td><span style="color: green">successful</span></td>
                        <?php elseif($od->payment_status == UNSUCCESSFUL): ?>
                        <td><span style="color: red">unsuccessful</span></td>
                        <?php else: ?>
                        <td><span style="color: red">failed</span></td>
                        <?php endif; ?>
                        
                        <td><a href="javascript:void(0);" data-target="#order-view" data-toggle="modal" data-whatever="<?php echo e($od->id); ?>"><i class="fa fa-eye"></i></a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
                </table>
                <?php echo e($order->links('front.pagination')); ?>

                </div>
           <?php echo $__env->make('includes.user-side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<!-- =-=-=-=-=-=-= order view =-=-=-=-=-=-= -->
<div id="order-view" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" style="z-index: 100000 !important;">
    <div class="modal-dialog modal-lg">
    <div class="modal-content">
            <div class="dash">

        </div>
    </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   $('#order-view').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget) // Button that triggered the modal
        var id = button.data('whatever') // Extract info from data-* attributes
        var modal = $(this);
        var dataString = 'id=' + id;

          $.ajax({
              type: "GET",
              url: "/user/order/view/",
              data: dataString,
              cache: false,
              success: function (data) {
                  //console.log(data);
                  modal.find('.dash').html(data);
              },
              error: function(err) {
                  //console.log(err);
              }
          });
  })

  $(function () {
    // when the modal is closed
    $('#order-view').on('hidden.bs.modal', function () {
        // remove the bs.modal data attribute from it
        $(this).removeData('bs.modal');
        // and empty the modal-content element
        $('#modal-container .modal-content').empty();
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'layouts.user' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jesus-care\resources\views/user/orders.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Payment History'); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="background-image: url('<?php echo e(asset('images/bg2.jpg')); ?>');" class="breadcrumb-section jarallax pixels-bg" data-jarallax data-speed="0.6">
    <div class="container text-center">
        <h1>Payment History</h1>
        <ul>
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li><a href="javascript:void(0);">Page</a></li>
            <li><a href="javascript:void(0);">Payment History</a></li>
        </ul>
    </div>
</div>

<div class="section-block">
    <div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-12 col-12">
                <h4>My Payment History</h4>
                <p>All my payments</p>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>Transaction ID</th>
                        <th>Date Created</th>
                        <th>Amount (<?php echo e($comm->currency); ?>)</th>
                        <th>Payment Type</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $od): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($od->transaction_id); ?></td>
                        <td><?php echo e(date("d F, Y",strtotime($od->created_at))); ?></td>
                        <td><?php echo e(number_format($od->amount,2)); ?></td>
                        <td><?php echo e($od->gateway->name); ?></td>
                        <?php if($od->status == SUCCESSFUL): ?>
                        <td><span style="color: green">successful</span></td>
                        <?php elseif($od->status == UNSUCCESSFUL): ?>
                        <td><span style="color: red">unsuccessful</span></td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
                </table>
                <?php echo e($data->links('front.pagination')); ?>

                </div>
           <?php echo $__env->make('includes.user-side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'layouts.user' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jesus-care\resources\views/user/payments.blade.php ENDPATH**/ ?>
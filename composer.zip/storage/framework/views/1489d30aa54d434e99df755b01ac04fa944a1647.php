<?php $__env->startSection('title','Order Status'); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="error-section-2 text-center">

        <div class="container">
            <?php if($status->status == SUCCESSFUL): ?>
            <img src="<?php echo e(asset('images/success.PNG')); ?>" alt="">
            <h1 style="font-size: 60px; color: green">Order Successful</h1>
            <p><strong>Your payment is successful!! <br> Your Transaction Reference is <span style="color: green"><?php echo e($status->transaction_id); ?></span></strong></p>
            <p><strong>We are already processing your order and one of us will contact you shortly.</strong></p>
            <a href="<?php echo e(url('user/orders')); ?>" class="button-md button-primary-bordered mt-30">View Transactions</a>
            <br><br><br><br>
            <?php elseif($status->status == UNSUCCESSFUL): ?>

            <img src="<?php echo e(asset('images/unsuccess.PNG')); ?>" alt="">
            <h1 style="font-size: 60px">Order Unsuccessful</h1>
            <p><strong>Your payment is unsuccessful!! <br> Your Transaction Reference is <span style="color: red"><?php echo e($status->transaction_id); ?></span></strong></p>
            <p><strong></strong></p>
            <a href="<?php echo e(url('user/orders')); ?>" class="button-md button-primary-bordered mt-30">Make Payment</a>

            <?php else: ?>

            <h1>404</h1>
            <h2>Oops, This Page Could Not Be Found!</h2>
            <h3>We couldnt find the page you were looking for.</h3>
            <a href="<?php echo e(url('/')); ?>" class="button-md button-primary-bordered mt-30">Back Home</a>

            <?php endif; ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'layouts.app' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jesus-care\resources\views/front/order-status.blade.php ENDPATH**/ ?>
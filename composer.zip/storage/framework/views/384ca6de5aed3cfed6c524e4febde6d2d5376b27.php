<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="rev_slider_wrapper bg-arrows" style="border-bottom: 50px; border-bottom-style: solid; border-bottom-color: #202CA6;">
        <div id="rev_slider" class="rev_slider fullscreenbanner">
            <ul>
                <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <img src="<?php echo e(asset('images/banners/'.$sl->image)); ?>" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg">
                    <div style="margin-bottom: 20px" class="slide-title tp-caption tp-resizeme text-center-sm" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['-20','-20', '-150', '-350']" data-fontsize="['30','40', '40', '30']" data-fontweight="400" data-lineheight="['80','50', '50', '135']" data-width="['600','500','650']" data-height="none" data-color="#fff" data-whitespace="normal" data-start="500" data-responsive_offset="on">
                        <strong><?php echo $sl->title; ?></strong>
                    </div>
                    <div style="margin-bottom: 60px;" class="slide-subtitle tp-caption tp-resizeme text-center-sm" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['90','90', '15', '15']" data-fontsize="['18', '18', '18', '18']" data-fontweight="300" data-lineheight="['30']" data-width="['600','500','650']" data-transform_idle="o:1;" data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1200;e:Power1.easeInOut;" data-transform_out="opacity:0;s:1000;s:1000;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-start="1500" data-color="#fff" data-splitin="none" data-splitout="none">
                        <?php echo $sl->description; ?>

                    </div>
                    <a href="<?php echo e($sl->link); ?>"><div class="tp-caption rev-btn tp-resizeme slider-btn button-primary" id="slide-1081-layer-13" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['160','160','160','30']" data-fontsize="['15','15','15','15']" data-fontweight="600" data-lineheight="['50','50','50','50']" data-width="['200','200','200','200']" data-height="none" data-whitespace="nowrap" data-start="1500" data-type="button" data-actions='[{"event":"click","action":"scrollbelow","offset":"-70px","delay":"","speed":"2500","ease":"Power1.easeInOut"}]' data-responsive_offset="on" data-splitin="none" data-splitout="none" data-frames='[{"delay":900,"speed":1000,"frame":"0","from":"y:50px;opacity:0;fb:10px;fbr:100;","to":"o:1;fb:0;fbr:100;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;fb:0;fbr:100;","ease":"Power3.easeInOut"},{"frame":"hover","speed":"200","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;fb:0;fbr:110%;","style":"c:rgba(255,255,255,1);bs:solid;bw:0 0 0 0;"}]' data-textAlign="['center','center','center','center']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="">
                        <?php echo e($sl->button_name); ?>

                    </div></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>


<div class="section-block grey-bg background-shape-3">
        <div class="container">
            <div class="row">
                <div class="col-md-5 col-sm-5 col-12">
                    <div class="section-heading">
                        <small class="uppercase">Who we are</small>
                        <h4 class="semi-bold">We're <?php echo e($comm->shortname); ?></h4>
                    </div>
                    <div class="text-content mt-15">
                        <p><?php echo $comm->shortdescrpt; ?></p>
                    </div>
                    
                    <a href="<?php echo e(url('about')); ?>" class="button-md button-primary mt-30">Read More</a>
                </div>
                <div class="col-md-6 col-sm-6 col-12 offset-md-1">
                    <img src="<?php echo e(asset('images/logo/'.$comm->about)); ?>" class="position-relative extra-rounded-border shadow-primary z-index-9 mt-30-xs" alt="img">
                </div>
            </div>

            <div class="row mt-40">
                <div class="col-lg-4 col-md-4 col-sm-4 col-12">
                    <div class="features-box">
                        <div class="features-box-icon">
                            <i class="icon-vision"></i>
                        </div>
                        <div class="features-box-content">
                            <h3>Our Vision</h3>
                            <p><?php echo e($comm->vision); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-12">
                    <div class="features-box">
                        <div class="features-box-icon">
                            <i class="icon-mission"></i>
                        </div>
                        <div class="features-box-content">
                            <h3>Mission Statement</h3>
                            <p><?php echo e($comm->mission); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-12">
                    <div class="features-box">
                        <div class="features-box-icon">
                            <i class="icon-chess"></i>
                        </div>
                        <div class="features-box-content">
                            <h3>Our Core Values</h3>
                            <p><?php echo e($comm->value); ?></p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div><br>

    <?php if(count($ministry) >= 1): ?>
        <div class="container">
            <div class="section-heading text-center">
                <h3 class="semi-bold font-size-35" style="color: #202CA6; font-family: fantasy">Ministry</h3>
                <div class="section-heading-line line-thin"></div>
            </div>
            <div class="cases-md">
                <div class="row mt-30">
                    <?php $__currentLoopData = $ministry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-12">
                        <div class="service-box-2">
                            <div class="service-box-2-icon">
                                <a href="<?php echo e(url('ministry/'.$pr->slug)); ?>"> <i class="fas fa-arrow-right"></i> </a>
                            </div>
                            <img src="<?php echo e(asset('images/ministries/'.$pr->image)); ?>" style="height: 300px" alt="img">
                            <div class="service-box-2-overlay" style="background: rgba(0,0,0,0.6); width: 100%; height: 80px;">
                                <div class="service-box-2-text" >
                                    <h6><a href="<?php echo e(url('ministry/'.$pr->url)); ?>" style="font-size: 16px"><?php echo e($pr->name); ?></a></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <a href="<?php echo e(url('ministries')); ?>" class="button-simple-primary mt-20">View All Ministry <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>
    <?php endif; ?>


    <?php if(count($events) >= 1): ?>
    <div class="section-block">
        <div class="container">
        <div class="section-heading text-center">
                <h3 class="semi-bold font-size-35" style="color: #202CA6; font-family: fantasy">Upcoming Events</h3>
                <div class="section-heading-line line-thin"></div>
            </div>
            <div class="row">
                <div class="col-md-9 col-sm-12 col-12">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="testmonial-box">
                        <div class="testmonial-box-content">
                            <div class="row">
                                <div class="col-md-5 col-sm-12 col-12">
                                    <img src="<?php echo e(asset('images/events/'.$aw->image)); ?>">
                                </div>
                                <div class="col-md-7 col-sm-12 col-12">
                                    <h3 style="font-size: 22px;"><?php echo e($aw->title); ?></h3><strong><?php echo e(date("d M, Y",strtotime($aw->start_date))); ?> - <span><?php echo e(date("d M, Y",strtotime($aw->end_date))); ?></span></strong>
                                    <p><?php echo substr($aw->description,0,200); ?>...</p><br>
                                    <a href="<?php echo e(url('event/'.$aw->slug)); ?>" class="button-simple-primary mt-20">Read More <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            
                <div class="col-md-3 col-sm-12 col-12">
                    <div class="blog-post-right">
                        <h4 class="blog-widget-title" style="font-size: 25px; font-family: fantasy">Parish Desk</h4>
                        <div class="row mt-40"> 
                            <div class="col-md-12 col-sm-12 col-12"> 
                                <div class="testmonial-box-2"> <i class="quote-icon fa fa-quote-left"></i> 
                                    <p><?php echo $message->message; ?></p>
                                    <div class="d-table"> 
                                        <!-- <img src="img/content/testmonials/t-1.jpg" class="testmonial-img" alt="img">  -->
                                        <div class="d-table-cell"> 
                                            <h4><?php echo e($message->message_by); ?></h4> <strong><?php echo e($message->position); ?></strong> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                       

                    </div>
                </div>

            </div>
        </div>
    </div>
    <?php endif; ?>




 


 <div class="container">
        <div class="section-heading text-center">
            <h3 class="semi-bold" style="color: #202CA6; font-family: fantasy">Featured Testimonies</h3>
            <div class="section-heading-line"></div>
            <p>What God cannot do does not exist. See evidence of God's goodness and faithfulness among His people.</p>
        </div>
        <div class="row">
            <div class="owl-carousel owl-theme testmonials-carousel">
                <?php $__currentLoopData = $testimony; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="testmonial-box">
                    <div class="testmonial-box-icon">
                        <img src="<?php echo e(asset('images/testimonials/'.$test->image)); ?>">
                    </div>
                    <div class="testmonial-box-content">
                        <h3><?php echo e($test->name); ?></h3><strong><?php echo e($test->location); ?></strong>
                        <p><?php echo $test->testimony; ?></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>  

    <div class="section-block grey-bg jarallax" data-jarallax data-speed="0.9" style="background-image: url('img/content/business/bg-map.png')">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-12 col-12">
                    <div class="section-heading">
                        <h3 class="semi-bold">Contact Us</h3>
                        <p>You acn easily reach us with the details below.</p>
                    </div>
                    <div>
                        <div class="contact-icon-box">
                            <i class="icon-phone-book"></i>
                            <h4>Direct line numbers</h4>
                            <h5><?php echo e($comm->tel); ?> / <?php echo e($comm->tel2); ?></h5>
                        </div>
                        <div class="contact-icon-box">
                            <i class="icon-opened-email-outlined-interface-symbol"></i>
                            <h4>Our Email</h4>
                            <h5><?php echo e($comm->email); ?> / <?php echo e($comm->email2); ?></h5>
                        </div>
                        <div class="contact-icon-box">
                            <i class="icon-location"></i>
                            <h4>Ministry Address</h4>
                            <h5><?php echo e($comm->address); ?></h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12 col-12">
                    <div class="pl-45-md">
                        <div class="callback-block">
                            <h4 class="bold text-center">Request a Call Back</h4>
                            <div class="section-heading-line line-thin"></div>
                            <div class="text-content-big text-center mt-20">
                                <p>Please complete the form</p>
                            </div>
                            <form id="contact-form" class="primary-form mt-30">
                                <?php echo e(csrf_field()); ?>

                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-12">
                                        <input type="text" name="name" placeholder="Name*" required>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-12">
                                        <input type="text" name="email" placeholder="Email Address*" required>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-12">
                                        <input type="text" name="phone" placeholder="Phone Number*" required>
                                    </div>
                                    <div class="col-12">
                                        <textarea placeholder="Message*" name="message" required></textarea>
                                    </div>
                                </div>
                                <div class="text-center mt-15">
                                    <button type="submit" class="button-md button-primary text-uppercase ml-0">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if(count($blog) >= 1): ?>
    <div class="section-block">
        <div class="container">
            <div class="section-heading text-center">
                <h3 class="semi-bold" style="color: #202CA6; font-family: fantasy">Latest Blog Post</h3>
                <div class="section-heading-line line-thin dark-bg"></div>
                <p>See our latest blog post</p>
            </div>
            <div class="row mt-40">
                <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-sm-4 col-12">
                    <div class="blog-grid">
                        <img src="<?php echo e(asset('images/blog/'.$blog->image)); ?>" style="height: 250px; max-width: 500px">
                        <div class="blog-team-box">
                            <h6><?php echo e(date("M d, Y",strtotime($blog->created_at))); ?></h6>
                        </div>
                        <h4><a href="<?php echo e(url('news/'.$blog->url)); ?>"><?php echo $blog->title; ?></a></h4>
                        <p><?php echo substr($blog->description,0,300); ?></p>
                        <a href="<?php echo e(url('blog/'.$blog->slug)); ?>" class="button-simple-primary mt-20">Read More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
$('#contact-form').submit(function(e){
		e.preventDefault();
        open_loader('#page');

		var form = $("#contact-form")[0];
		var _data = new FormData(form);
		$.ajax({
			url: '<?php echo e(url("/home/ajax/contact")); ?>',
			data: _data,
			enctype: 'multipart/form-data',
			processData: false,
			contentType:false,
			type: 'POST',
			success: function(data){
				if(data.status == "success"){
					toastr.success(data.message, data.status);
					window.setTimeout(function(){location.reload();},3000);
                    close_loader('#page');
                    } else{
                        toastr.error(data.message, data.status);
                        close_loader('#page');
                    }
			},
			error: function(result){
				toastr.error('Check Your Network Connection !!!','Network Error');
                close_loader('#page');
			}
		});
		return false;
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'layouts.home' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jesus-care\resources\views/front/index.blade.php ENDPATH**/ ?>
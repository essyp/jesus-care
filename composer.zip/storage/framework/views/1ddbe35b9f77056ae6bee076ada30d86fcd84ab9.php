<?php $__env->startSection('title','Products'); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="background-image: url('<?php echo e(asset('images/logo/'.$comm->background_image)); ?>');" class="breadcrumb-section jarallax pixels-bg" data-jarallax data-speed="0.6">
    <div class="container text-center">
        <h1>Products</h1>
        <ul>
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li><a href="javascript:void(0);">Pages</a></li>
            <li><a href="javascript:void(0);">Products</a></li>
        </ul>
    </div>
</div>
<div class="section-block">
<div class="container">
    <div class="row">
        <div class="col-md-9 col-sm-8 col-12">
            <?php if(count($data) >= 1): ?>
        <div class="row">
       <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 col-sm-6 col-12">
            <a href="<?php echo e(url('shop/'.$pr->slug)); ?>"><div class="shop-1">
                <img src="<?php echo e(asset('images/products/'.$pr->image)); ?>" style="height: 300px; max-width: 100%" />
               <div class="shop-classic-sale-img shop-classic-hot-img">
                    <h4><?php echo e($pr->pname); ?></h4>
                    <h4><?php echo e($comm->currency); ?><?php echo e(number_format($pr->price)); ?></h4>
                </div>
                <h6 style="font-size: 13px"><?php echo e($pr->pname); ?></h6>
                <p><span></span> <?php echo e($comm->currency); ?><?php echo e(number_format($pr->price)); ?></p>
                </div></a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
            <p>No available data for this page!! <strong><a style="color: brown" href="<?php echo e(url('/')); ?>">Return to Home</a></strong></p>
            <?php endif; ?>
        </div>

        <?php echo $__env->make('includes/product-side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    </div>
    <?php echo e($data->links('front.pagination')); ?>

</div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'layouts.app' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jesus-care\resources\views/front/products.blade.php ENDPATH**/ ?>
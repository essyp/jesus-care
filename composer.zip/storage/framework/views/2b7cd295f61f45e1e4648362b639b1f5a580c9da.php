<?php if($paginator->hasPages()): ?>
<div class="pagination mt-50">
    
        
        <?php if($paginator->onFirstPage()): ?>
            
        <?php else: ?>
            <a class="prev" href="<?php echo e($paginator->previousPageUrl()); ?>"><span aria-hidden="true" class="fa fa-angle-left"></span></a>
        <?php endif; ?>
        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(is_string($element)): ?>
                <li class="disabled page-item"><span><?php echo e($element); ?></span></li>
            <?php endif; ?>
            
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <a href="" class="active" ><?php echo e($page); ?><span class="sr-only">(current)</span></a>
                    <?php else: ?>
                        <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <?php if($paginator->hasMorePages()): ?>
            <a class="next" href="<?php echo e($paginator->nextPageUrl()); ?>"><span aria-hidden="true" class="fa fa-angle-right"></span></a>
        <?php else: ?>
            
        <?php endif; ?>
    
</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\jesus-care\resources\views/front/pagination.blade.php ENDPATH**/ ?>
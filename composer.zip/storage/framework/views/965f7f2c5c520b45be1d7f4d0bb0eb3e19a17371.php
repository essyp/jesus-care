<div class="col-md-3 col-sm-12 col-12">
    <?php if(!empty($user->image)): ?>
    <img src="<?php echo e(asset('images/users/'.$user->image)); ?>" style="max-height: 70px; max-width: 70px; border-radius: 50px; float: right">
    <?php else: ?>
    <img src="<?php echo e(asset('images/avatar.png')); ?>" style="max-height: 70px; max-width: 70px; border-radius: 50px; float: right">
    <?php endif; ?>
    <div class="blog-post-right">
        <h4 class="blog-widget-title"><?php echo e($user->fname); ?> <?php echo e($user->lname); ?></h4><br>
        <p>ID: <strong><?php echo e($user->ref_id); ?></strong></p>
        <div class="blog-post-categories mt-20">
            <ul>
                 <li><a href="<?php echo e(url('user/account')); ?>">Account<span></span></a></li>
                 <li><a href="<?php echo e(url('user/orders')); ?>">Orders<span></span></a></li>
                 <li><a href="<?php echo e(url('user/payments')); ?>">Payments<span></span></a></li>
                 <li><a href="<?php echo e(url('user/change-password')); ?>">Change Password<span></span></a></li>
                 <li><a href="<?php echo e(url('user/account-update')); ?>">Update Account<span></span></a></li>
                 <li><a href="<?php echo e(url('logout')); ?>">Logout<span></span></a></li>
            </ul>
        </div>

    </div>
</div><?php /**PATH C:\xampp\htdocs\jesus-care\resources\views/includes/user-side.blade.php ENDPATH**/ ?>
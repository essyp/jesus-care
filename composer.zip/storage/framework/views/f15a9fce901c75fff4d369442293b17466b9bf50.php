<?php $__env->startSection('title', 'Account Update'); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="background-image: url('<?php echo e(asset('images/bg2.jpg')); ?>');"  class="breadcrumb-section jarallax pixels-bg" data-jarallax data-speed="0.6">
    <div class="container text-center">
        <h1>Account Update</h1>
        <ul>
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li><a href="javascript:void(0);">Page</a></li>
            <li><a href="javascript:void(0);">Account Update</a></li>
        </ul>
    </div>
</div>

<div class="section-block">
    <div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-12 col-12">
                <div class="section-heading">
                    <h6 class="semi-bold">Update Account Information</h6>
                </div>
                <form id="update-form" class="primary-form-2 mt-15">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <div class="col-sm-6 col-12">
                            <label>First Name</label>
                            <input type="text" name="fname" value="<?php echo e($user->fname); ?>" required>
                        </div>
                        <div class="col-sm-6 col-12">
                            <label>Last Name</label>
                            <input type="text" name="lname" value="<?php echo e($user->lname); ?>" required>
                        </div>
                        <div class="col-sm-6 col-12">
                            <label>Email Address</label>
                            <input type="email" value="<?php echo e($user->email); ?>" readonly>
                        </div>
                        <div class="col-sm-6 col-12">
                            <label>Phone Number</label>
                            <input type="tel" name="tel" value="<?php echo e($user->tel); ?>" required>
                        </div>
                        <div class="col-sm-12 col-12">
                            <label>Contact Address</label>
                            <input type="text" name="address" value="<?php echo e($user->address); ?>" required>
                        </div>
                        <div class="col-sm-8 col-12">
                            <label>Profile Image</label>
                            <input type="file" id="imgInp" name="image" accept="image/*">
                        </div>
                        <div class="col-sm-4 col-12">
                            <img id="blah" src="<?php echo e(asset('images/users/'.$user->avatar)); ?>" style="max-width: 100px; max-height: 100px"/>
                        </div>
                        </div>
                    <div class="row mt-15">
                        <div class="text-right">
                            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>" required>
                            <button type="submit" class="button-md button-primary">Update Account</button>
                        </div>
                    </div>
                </form>
                </div>
           <?php echo $__env->make('includes.user-side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    function readURL(input) {

        if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function(e) {
            $('#blah').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
        }
        }

        $("#imgInp").change(function() {
        readURL(this);
    });

    $('#update-form').submit(function(e){
     e.preventDefault();
     //$('#quote').modal('hide');
     open_loader('#page');

     var form = $("#update-form")[0];
     var _data = new FormData(form);
     $.ajax({
         url: '<?php echo e(url("user/account-update")); ?>',
         data: _data,
         enctype: 'multipart/form-data',
         processData: false,
         contentType:false,
         type: 'POST',
         success: function(data){
             if(data.status == "success"){
                 toastr.success(data.message, data.status);
                 window.setTimeout(function(){location.reload();},2000);
                 close_loader('#page');
                 } else{
                     toastr.error(data.message, data.status);
                     close_loader('#page');
                 }
         },
         error: function(result){
             toastr.error('Check Your Network Connection !!!','Network Error');
             close_loader('#page');
         }
     });
     return false;
 });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'layouts.user' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jesus-care\resources\views/user/account-update.blade.php ENDPATH**/ ?>
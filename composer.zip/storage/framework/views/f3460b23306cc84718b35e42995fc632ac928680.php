<?php $__env->startSection('title','dashboard'); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!--main content start-->
<div id="content" class="ui-content ui-content-aside-overlay">
                <div class="ui-content-body">

                    <div class="ui-container">

                        <!--page title and breadcrumb start -->
                        <div class="row">
                            <div class="col-md-8">
                                <h1 class="page-title"> Admin Dashboard
                                    <small></small>
                                </h1>
                            </div>
                            <div class="col-md-4">
                                <ul class="breadcrumb pull-right">
                                    <li>Home</li>
                                    <li><a class="active">Dashboard</a></li>
                                </ul>
                            </div>
                        </div>
                        <!--page title and breadcrumb end -->

                        <!--states start-->
                        <div class="row">
                            <div class="col-md-3 col-sm-6">
                                <div class="panel short-states bg-danger">
                                    <div class="pull-right state-icon">
                                        <i class="fa fa-shopping-cart"></i>
                                    </div>
                                    <div class="panel-body">
                                        <h1 class="light-txt"><?php echo e($totalProduct); ?></h1>
                                        <div class=" pull-right"><?php echo e($totalProduct); ?> <i class="fa fa-bolt"></i></div>
                                        <strong class="text-uppercase">TOTAL PRODUCT</strong>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6">
                                <div class="panel short-states bg-info">
                                    <div class="pull-right state-icon">
                                        <i class="fa fa-users"></i>
                                    </div>
                                    <div class="panel-body">
                                        <h1 class="light-txt"><?php echo e($totalOrder); ?></h1>
                                        <div class=" pull-right"><?php echo e($totalOrder); ?> <i class="fa fa-level-up"></i></div>
                                        <strong class="text-uppercase">Total Order</strong>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6">
                                <div class="panel short-states bg-warning">
                                    <div class="pull-right state-icon">
                                        <i class="fa fa-laptop"></i>
                                    </div>
                                    <div class="panel-body">
                                        <h1 class="light-txt"><?php echo e($totalUser); ?></h1>
                                        <div class=" pull-right"><?php echo e($totalUser); ?> <i class="fa fa-level-down"></i></div>
                                        <strong class="text-uppercase">Total User</strong>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6">
                                <div class="panel short-states bg-primary">
                                    <div class="pull-right state-icon">
                                        <i class="fa fa-pie-chart"></i>
                                    </div>
                                    <div class="panel-body">
                                        <h1 class="light-txt"><?php echo e($totalBlog); ?></h1>
                                        <div class=" pull-right"><?php echo e($totalBlog); ?> <i class="fa fa-level-up"></i></div>
                                        <strong class="text-uppercase">Total Blog Post</strong>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-6">
                                <div class="panel short-states bg-primary">
                                    <div class="pull-right state-icon">
                                        <i class="fa fa-pie-chart"></i>
                                    </div>
                                    <div class="panel-body">
                                        <h1 class="light-txt"><?php echo e($totalMinistry); ?></h1>
                                        <div class=" pull-right"><?php echo e($totalMinistry); ?> <i class="fa fa-level-up"></i></div>
                                        <strong class="text-uppercase">Total Ministry</strong>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-6">
                                <div class="panel short-states bg-primary">
                                    <div class="pull-right state-icon">
                                        <i class="fa fa-pie-chart"></i>
                                    </div>
                                    <div class="panel-body">
                                        <h1 class="light-txt"><?php echo e($totalEvent); ?></h1>
                                        <div class=" pull-right"><?php echo e($totalEvent); ?> <i class="fa fa-level-up"></i></div>
                                        <strong class="text-uppercase">Total Events</strong>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-6">
                                <div class="panel short-states bg-primary">
                                    <div class="pull-right state-icon">
                                        <i class="fa fa-pie-chart"></i>
                                    </div>
                                    <div class="panel-body">
                                        <h1 class="light-txt"><?php echo e($comm->currency); ?><?php echo e(number_format($totalAmount,2)); ?></h1>
                                        <div class=" pull-right"><?php echo e($totalAmount); ?> <i class="fa fa-level-up"></i></div>
                                        <strong class="text-uppercase">Total Payments</strong>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--states end-->



                        <div class="row">
                            <!--quote start-->
                            <div class="col-md-12">
                                <?php if(count($users) >= 1): ?>
                                <div class="panel">
                                    <header class="panel-heading panel-border">
                                        Latest Users
                                        <span class="tools pull-right">
                                            <a class="refresh-box fa fa-repeat" href="javascript:;"></a>
                                            <a class="collapse-box fa fa-chevron-down" href="javascript:;"></a>
                                            <a class="close-box fa fa-times" href="javascript:;"></a>
                                        </span>
                                    </header>
                                    <div class="panel-body">
                                        <div class="order-short-info">
                                            <a href="<?php echo e(url('/admin/users')); ?>" class="pull-right pull-left-xs btn btn-primary btn-sm">View All Quotes</a>
                                        </div>
                                        <hr/>
                                        <div class="table-responsive">
                                            <table  class="table table-hover latest-order">
                                                <thead>
                                                <tr>
                                                    <th>Member ID</th>
                                                    <th>First Name</th>
                                                    <th>Last Name</th>
                                                    <th>Email</th>
                                                    <th>Phone Number</th>
                                                    <th>Created</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($user->ref_id); ?></td>
                                                    <td><?php echo e($user->fname); ?></td>
                                                    <td><?php echo e($user->lname); ?></td>
                                                    <td><a href="javascript:void(0);"><?php echo e($user->email); ?></a></td>
                                                    <td><?php echo e($user->tel); ?></td>
                                                    <td><?php echo e($user->created_at); ?></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                            <!--quote end-->
                        </div>



                        <div class="row">
                            <!--order start-->
                            <div class="col-md-12">
                                <?php if(count($orders) >= 1): ?>
                                <div class="panel">
                                    <header class="panel-heading panel-border">
                                        Latest Orders
                                        <span class="tools pull-right">
                                            <a class="refresh-box fa fa-repeat" href="javascript:;"></a>
                                            <a class="collapse-box fa fa-chevron-down" href="javascript:;"></a>
                                            <a class="close-box fa fa-times" href="javascript:;"></a>
                                        </span>
                                    </header>
                                    <div class="panel-body">
                                        <div class="order-short-info">
                                            <a href="<?php echo e(url('/admin/orders')); ?>" class="pull-right pull-left-xs btn btn-primary btn-sm">View Full Orders</a>
                                        </div>
                                        <hr/>
                                        <div class="table-responsive">
                                            <table  class="table table-hover latest-order">
                                                <thead>
                                                <tr>
                                                    <th>Order ID</th>
                                                    <th>Customer Name</th>
                                                    <th>Total Amount (<?php echo e($comm->currency); ?>)</th>
                                                    <th>Created Date</th>
                                                    <th>Payment Status</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($o->order_code); ?></td>
                                                    <td><?php echo e($o->user->fname); ?> <?php echo e($o->user->lname); ?></td>
                                                    <td><?php echo e(number_format($o->total_amount)); ?></td>
                                                    <td><?php echo e($o->created_at); ?></td>
                                                    <td>
                                                    <?php if($o->payment_status==SUCCESSFUL): ?>
                                                        <span class="label label-success">successful</span>
                                                        <?php else: ?>
                                                        <span class="label label-danger">unsuccessful</span>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                            <!--order end-->
                        </div>


                    </div>


                </div>
            </div>
            <!--main content end-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'layouts.admin' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jesus-care\resources\views/admin/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title','Events'); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="background-image: url('<?php echo e(asset('images/logo/'.$comm->background_image)); ?>');" class="breadcrumb-section jarallax pixels-bg" data-jarallax data-speed="0.6">
    <div class="container text-center">
        <h1>Events</h1>
        <ul>
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li><a href="javascript:void(0);">Events</a></li>
        </ul>
    </div>
</div>

<div class="section-block">
        <div class="container">
            <div class="row">
                <div class="col-md-9 col-sm-12 col-12">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="testmonial-box">
                        <div class="testmonial-box-content">
                            <div class="row">
                                <div class="col-md-5 col-sm-12 col-12">
                                    <img src="<?php echo e(asset('images/events/'.$aw->image)); ?>">
                                </div>
                                <div class="col-md-7 col-sm-12 col-12">
                                    <h3 style="font-size: 22px;"><?php echo e($aw->title); ?></h3><strong><?php echo e(date("d M, Y",strtotime($aw->start_date))); ?> - <span><?php echo e(date("d M, Y",strtotime($aw->end_date))); ?></span></strong>
                                    <p><?php echo substr($aw->description,0,200); ?>...</p><br>
                                    <a href="<?php echo e(url('event/'.$aw->slug)); ?>" class="button-simple-primary mt-20">Read More <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php echo e($data->links('front.pagination')); ?>

                </div>
            
                <div class="col-md-3 col-sm-12 col-12">
                    <div class="blog-post-right">
                        <h4 class="blog-widget-title" style="font-size: 25px; font-family: fantasy">Parish Desk</h4>
                        <div class="row mt-40"> 
                            <div class="col-md-12 col-sm-12 col-12"> 
                                <div class="testmonial-box-2"> <i class="quote-icon fa fa-quote-left"></i> 
                                    <p><?php echo $message->message; ?></p>
                                    <div class="d-table"> 
                                        <!-- <img src="img/content/testmonials/t-1.jpg" class="testmonial-img" alt="img">  -->
                                        <div class="d-table-cell"> 
                                            <h4><?php echo e($message->message_by); ?></h4> <strong><?php echo e($message->position); ?></strong> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <h4 class="blog-widget-title">Ministries</h4>
                        <div class="blog-post-categories mt-20">
                            <ul>
                                <?php $__currentLoopData = $ministry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(url('ministry/'.$serv->slug)); ?>"><?php echo e($serv->name); ?><span></span></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <h4 class="blog-widget-title">Featured Blog</h4>
                        <div class="top-news mt-20">
                            <?php $__currentLoopData = $blogfeatured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="top-news-info">
                                <div class="row">
                                    <div class="col-md-4 col-sm-4 col-12 pr-0">
                                        <img src="<?php echo e(asset('images/blog/'.$blog->image)); ?>" alt="img">
                                    </div>
                                    <div class="col-md-8 col-sm-8 col-12">
                                        <h3><a href="<?php echo e(url('blog/'.$blog->slug)); ?>"><?php echo e($blog->title); ?></a></h3>
                                        <h6><?php echo e(date("d F, Y",strtotime($blog->created_at))); ?></h6>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

<?php echo $__env->make('includes.donate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'layouts.app' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jesus-care\resources\views/front/events.blade.php ENDPATH**/ ?>
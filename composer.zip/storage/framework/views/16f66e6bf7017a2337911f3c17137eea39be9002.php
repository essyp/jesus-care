<div class="col-md-3 col-sm-4 col-12">
    <div class="sidebar-primary mt-15">
        <h3 class="sidebar-title">Search Products</h3>
        <form action="<?php echo e(url('/shop/search-product')); ?>" method="post" class="primary-form mt-20">
            <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="col-10">
                    <input type="text" name="q" placeholder="Search product...">
                </div>
                <div class="col-2 pl-0">
                    <button type="submit" class="button-text button-lg rounded-border full-width h-49 px-0">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>
        </form>
        <h3 class="sidebar-title mt-10">Categories</h3>
        <ul class="vertical-nav-1 mt-15">
            <?php $__currentLoopData = $productcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(url('shop/category/'.$ct->slug)); ?>"><?php echo e($ct->name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <?php if(count($productfeatured) >= 1): ?>
        <h3 class="sidebar-title mt-40">Products</h3>
        <div class="top-news mt-25">
            <?php $__currentLoopData = $productfeatured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="shop-product">
                <div class="row">
                    <div class="col-md-4 col-sm-4 col-12 pr-0">
                        <img src="<?php echo e(asset('images/products/'.$pf->image)); ?>" alt="img">
                    </div>
                    <div class="col-md-8 col-sm-8 col-12">
                        <h3><a href="<?php echo e(url('shop/'.$pf->slug)); ?>"><?php echo e($pf->pname); ?></a></h3>
                        <h6><?php echo e($pf->cat->name); ?></h6>
                        <div class="price-star clearfix">
                            <ul>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\jesus-care\resources\views/includes/product-side.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title','Shopping Cart'); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="background-image: url('<?php echo e(asset('images/bg2.jpg')); ?>');" class="breadcrumb-section jarallax pixels-bg" data-jarallax data-speed="0.6">
    <div class="container text-center">
        <h1>Shopping Cart</h1>
        
    </div>
</div>
    <div class="section-block grey-bg">
        <div class="container" id="refresh">
            <?php if(count($cart) >= 1): ?>
            <div class="row">
                <div class="col-md-8 col-sm-10 col-12" id="1">
                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="shop-cart-box">
                        <div class="row no-gutters">
                            <div class="col-md-1 col-sm-1 col-12 pr-0">
                                <div class="button-close">
                                    <a href="javascript:void(0);" data-id="<?php echo e($ct->id); ?>" class="close-box removeFromCart">
                                        <i class="ti-close"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-2 col-sm-2 col-12">
                                <div class="shop-cart-box-img">
                                    <img src="<?php echo e(asset('images/products/'.$ct->product->image)); ?>" style="max-height: 100px; max-width: 100px" alt="img">
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4 col-xs-12">
                                <div class="shop-cart-box-info">
                                    <h4><a href="<?php echo e(url('shop/'.$ct->slug)); ?>"><?php echo e($ct->product->pname); ?></a></h4>
                                    <span><?php echo e($comm->currency); ?><?php echo e(number_format($ct->price)); ?></span>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3 col-12">
                                <div class="shop-cart-box-quantity">
                                    <span><a href="javascript:void(0);" class="btn btn-danger decreasecart" data-id="<?php echo e($ct->id); ?>">-</a></span>
                                    <input type="text" value="<?php echo e($ct->quantity); ?>" style="width: 40px; height:30px">
                                    <span><a href="javascript:void(0);" class="btn btn-success increasecart" data-id="<?php echo e($ct->id); ?>">+</a></span>
                                </div>
                            </div>
                            <div class="col-md-2 col-sm-2 col-xs-12">
                                <div class="shop-cart-box-price">
                                    <h5><?php echo e($comm->currency); ?><?php echo e(number_format($ct->total)); ?></h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-4 col-sm-10 col-12">
                    <div class="shop-cart-info-price clearfix">
                        <ul class="right-info-price">
                            <li>Total Price: <h6><?php echo e($comm->currency); ?><?php echo e(number_format($total)); ?></h6></li>
                            <li>Vat 0%: <h6>0.00</h6></li>
                        </ul>
                        <div class="total-price">
                            <p>Total: <strong><?php echo e($comm->currency); ?><?php echo e(number_format($total,2)); ?></strong></p>
                        </div>
                    </div>
                    <div class="mt-25 right-holder">
                        <a href="<?php echo e(url('checkout')); ?>" class="button-md button-primary">Proceed to Checkout</a>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-12">
                    <p>Your cart is empty!! Go to <a href="<?php echo e(url('marketplace')); ?>">products</a> to add to your cart</p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>


    <?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'layouts.app' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jesus-care\resources\views/front/cart.blade.php ENDPATH**/ ?>